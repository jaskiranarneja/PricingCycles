/**
 * 
 */
package job.hirist.social.inputJson;

/**
 * @author Neeraj90
 *
 */
public class HandleBrakes {
	//sub parts
	String aHandleBrake,bHandleBrake,cHandleBrake,dHandleBrake;

	/**
	 * @return the aHandleBrake
	 */
	public String getaHandleBrake() {
		return aHandleBrake;
	}

	/**
	 * @param aHandleBrake the aHandleBrake to set
	 */
	public void setaHandleBrake(String aHandleBrake) {
		this.aHandleBrake = aHandleBrake;
	}

	/**
	 * @return the bHandleBrake
	 */
	public String getbHandleBrake() {
		return bHandleBrake;
	}

	/**
	 * @param bHandleBrake the bHandleBrake to set
	 */
	public void setbHandleBrake(String bHandleBrake) {
		this.bHandleBrake = bHandleBrake;
	}

	/**
	 * @return the cHandleBrake
	 */
	public String getcHandleBrake() {
		return cHandleBrake;
	}

	/**
	 * @param cHandleBrake the cHandleBrake to set
	 */
	public void setcHandleBrake(String cHandleBrake) {
		this.cHandleBrake = cHandleBrake;
	}

	/**
	 * @return the dHandleBrake
	 */
	public String getdHandleBrake() {
		return dHandleBrake;
	}

	/**
	 * @param dHandleBrake the dHandleBrake to set
	 */
	public void setdHandleBrake(String dHandleBrake) {
		this.dHandleBrake = dHandleBrake;
	}
	
	
}
