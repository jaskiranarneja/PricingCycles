/**
 * 
 */
package job.hirist.social.inputJson;

/**
 * @author Neeraj90
 *
 */
public class Wheels {
	//sub parts
	String spokes, rim, tube, tyre;

	/**
	 * @return the spokes
	 */
	public String getSpokes() {
		return spokes;
	}

	/**
	 * @param spokes the spokes to set
	 */
	public void setSpokes(String spokes) {
		this.spokes = spokes;
	}

	/**
	 * @return the rim
	 */
	public String getRim() {
		return rim;
	}

	/**
	 * @param rim the rim to set
	 */
	public void setRim(String rim) {
		this.rim = rim;
	}

	/**
	 * @return the tube
	 */
	public String getTube() {
		return tube;
	}

	/**
	 * @param tube the tube to set
	 */
	public void setTube(String tube) {
		this.tube = tube;
	}

	/**
	 * @return the tyre
	 */
	public String getTyre() {
		return tyre;
	}

	/**
	 * @param tyre the tyre to set
	 */
	public void setTyre(String tyre) {
		this.tyre = tyre;
	}
	
}
