/**
 * 
 */
package job.hirist.social.inputJson;

/**
 * @author Neeraj90
 *
 */
public class Seating {
	//sub parts
	String aSeat,bSeat,cSeat,dSeat;

	/**
	 * @return the aSeat
	 */
	public String getaSeat() {
		return aSeat;
	}

	/**
	 * @param aSeat the aSeat to set
	 */
	public void setaSeat(String aSeat) {
		this.aSeat = aSeat;
	}

	/**
	 * @return the bSeat
	 */
	public String getbSeat() {
		return bSeat;
	}

	/**
	 * @param bSeat the bSeat to set
	 */
	public void setbSeat(String bSeat) {
		this.bSeat = bSeat;
	}

	/**
	 * @return the cSeat
	 */
	public String getcSeat() {
		return cSeat;
	}

	/**
	 * @param cSeat the cSeat to set
	 */
	public void setcSeat(String cSeat) {
		this.cSeat = cSeat;
	}

	/**
	 * @return the dSeat
	 */
	public String getdSeat() {
		return dSeat;
	}

	/**
	 * @param dSeat the dSeat to set
	 */
	public void setdSeat(String dSeat) {
		this.dSeat = dSeat;
	}
	
}
