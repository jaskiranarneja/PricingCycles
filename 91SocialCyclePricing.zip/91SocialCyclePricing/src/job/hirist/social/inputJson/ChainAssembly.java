/**
 * 
 */
package job.hirist.social.inputJson;

/**
 * @author Neeraj90
 *
 */
public class ChainAssembly {
	//sub parts
	String aChain,bChain,cChain,dChain;

	/**
	 * @return the aChain
	 */
	public String getaChain() {
		return aChain;
	}

	/**
	 * @param aChain the aChain to set
	 */
	public void setaChain(String aChain) {
		this.aChain = aChain;
	}

	/**
	 * @return the bChain
	 */
	public String getbChain() {
		return bChain;
	}

	/**
	 * @param bChain the bChain to set
	 */
	public void setbChain(String bChain) {
		this.bChain = bChain;
	}

	/**
	 * @return the cChain
	 */
	public String getcChain() {
		return cChain;
	}

	/**
	 * @param cChain the cChain to set
	 */
	public void setcChain(String cChain) {
		this.cChain = cChain;
	}

	/**
	 * @return the dChain
	 */
	public String getdChain() {
		return dChain;
	}

	/**
	 * @param dChain the dChain to set
	 */
	public void setdChain(String dChain) {
		this.dChain = dChain;
	}
	
}
