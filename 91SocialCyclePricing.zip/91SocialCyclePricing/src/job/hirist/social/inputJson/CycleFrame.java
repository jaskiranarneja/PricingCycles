/**
 * 
 */
package job.hirist.social.inputJson;

/**
 * @author Neeraj90
 *
 */
public class CycleFrame {
	//price of various components
	String aFrame,bFrame,cFrame,dFrame;

	/**
	 * @return the aFrame
	 */
	public String getaFrame() {
		return aFrame;
	}

	/**
	 * @param aFrame the aFrame to set
	 */
	public void setaFrame(String aFrame) {
		this.aFrame = aFrame;
	}

	/**
	 * @return the bFrame
	 */
	public String getbFrame() {
		return bFrame;
	}

	/**
	 * @param bFrame the bFrame to set
	 */
	public void setbFrame(String bFrame) {
		this.bFrame = bFrame;
	}

	/**
	 * @return the cFrame
	 */
	public String getcFrame() {
		return cFrame;
	}

	/**
	 * @param cFrame the cFrame to set
	 */
	public void setcFrame(String cFrame) {
		this.cFrame = cFrame;
	}

	/**
	 * @return the dFrame
	 */
	public String getdFrame() {
		return dFrame;
	}

	/**
	 * @param dFrame the dFrame to set
	 */
	public void setdFrame(String dFrame) {
		this.dFrame = dFrame;
	}

}
