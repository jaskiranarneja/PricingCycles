package job.hirist.junit;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import job.hirist.social.ProdConsWithES;

class ProdConsWithESTest {

	@Test
	void testMain() {
		ProdConsWithES waiter = new ProdConsWithES();
		assertEquals("Testcase for ProdConsWithES", "Testcase for ProdConsWithES");
	}
	

}
